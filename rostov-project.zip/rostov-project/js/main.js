$(document).ready(function () {
    var modal = $('.modal'),
        modalBtn = $('[data-toggle="modal"]'),
        closeBtn = $('.modal__close');

    modalBtn.on('click', function (){
        modal.toggleClass('modal--visible');
    });
    closeBtn.on('click', function (){
        modal.toggleClass('modal--visible');
    });

    var mySwiper = new Swiper ('.swiper-container', {
        loop: true, 
        pagination: {
            el: '.swiper-pagination',
            type: 'bullets',
          },
        navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
        transition: 1000
    })
    
    var next = $('.swiper-button-next');
    var prev = $('.swiper-button-prev');
    var bullets = $('.swiper-pagination');

    next.css('left', prev.width() + 30 + bullets.width() + 30)
    bullets.css('left', prev.width() + 30)

    // активация WOW анимации
    new WOW().init();

    // валидация формы
    $('.modal__form').validate({
        errorClass: "invalid",
        rules: {
            // simple rule, converted to {required:true}
            userName: {
                required: true,
                minlength: 2,
                maxlength: 15
            },
            userPhone: "required",
            // compound rule
            userEmail: {
              required: true,
              email: true
            }
          },
        messages: {
            userName: {
                required: "Обязательное поле для ввода",
                minlength: "Имя должно быть более 2 букв",
                maxlength: "Имя должно быть не более 15 букв"
            },
            userPhone: "Обязательное поле для ввода",
            userEmail: {
              required: "Обязательное поле для ввода",
              email: "Введите в формате: name@domain.com"
            }
        },
        submitHandler: function(form) {
            $.ajax({
              type: "POST",
              url: "send.php",
              data: $(form).serialize(),
              success: function (response) {
                alert('Форма отправлена, мы свяжемся с вами через 10 минут');
                $(form)[0].reset();
                modal.removeClass('modal--visible');
              },
              error: function (response) {
                console.error('Ошибка запроса ' + response);
              }
            });
        }
    });

    $('.footer__form').validate({
      errorClass: "invalid",
      rules: {
          // simple rule, converted to {required:true}
          userName: {
              required: true,
              minlength: 2,
              maxlength: 15
          },
          userPhone: "required",
          userQuestion: "required"
        },
      messages: {
          userName: {
              required: "Обязательное поле для ввода",
              minlength: "Имя должно быть более 2 букв",
              maxlength: "Имя должно быть не более 15 букв"
          },
          userPhone: "Обязательное поле для ввода",
          userQuestion: "Обязательное поле для ввода"
        },
      submitHandler: function(form) {
          $.ajax({
            type: "POST",
            url: "send.php",
            data: $(form).serialize(),
            success: function (response) {
              alert('Форма отправлена, мы свяжемся с вами через 10 минут');
              $(form)[0].reset();
              modal.removeClass('modal--visible');
            },
            error: function (response) {
              console.error('Ошибка запроса ' + response);
            }
          });
      }
    });

    $('.control__form').validate({
      errorClass: "invalid",
      rules: {
          // simple rule, converted to {required:true}
          userName: {
              required: true,
              minlength: 2,
              maxlength: 15
          },
          userPhone: "required"
          // compound rule
        },
      messages: {
          userName: {
              required: "Обязательное поле для ввода",
              minlength: "Имя должно быть более 2 букв",
              maxlength: "Имя должно быть не более 15 букв"
          },
          userPhone: "Обязательное поле для ввода"
      },
    });

    // маска для телефона
    $('[type=tel').mask('+7(999) 99-99-999');

});